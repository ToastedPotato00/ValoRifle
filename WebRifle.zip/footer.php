<footer id="footer">
        <div class="wrap-footer">
            <h1>
                ValoRifle
            </h1>
            <h2>
                © ValoRifle. 2023
            </h2>
            <p class="closing">
                The only website you need for all information about valorant rifles
            </p>
            <a href="form.html" class="form">Satisfaction Form <br>Click here</a>
            <h3>
                Contacts:<br>
                Email: ValoRifle321@gmail.com<br>
                No: 123344599062
            </h3>
        </div>
    </footer>