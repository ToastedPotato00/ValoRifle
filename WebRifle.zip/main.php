<main class="main">
        <div id="def">
            <div class="wrap-text">
                <p class="defi">
                    Valorant is a competitive, team-based first-person shooter
                     developed by Riot Games. Set in a near-future Earth, 
                     players assume the roles of agents with unique abilities, 
                     engaging in intense 5v5 matches. Precise gunplay, 
                     strategic abilities, and teamwork are crucial in this 
                     tactical shooter that blends elements of FPS and 
                     hero-based gameplay.
                </p>
                <p class="info">
                    This website consist of information about a class of guns 
                    called rifles in valorant. To see them scroll down and 
                    click on the picture for more detailed status of the weapon. 
                </p>
            </div>
            
        </div>
        <div id="rifle-list">
            <div class="wrap-item">
                <div class="bulldog-bg">
                    <a href="bulldog.html">
                        <p class="bulldog-name"`>
                            Bulldog Rifle
                        </p>
                        <img src="Bulldog.png" alt="Bulldog" class="bulldog">
                    </a>
                </div>
                <div class="guardian-bg">
                    <a href="guardian.html">
                        <p class="guardian-name">
                            Guardian Rifle
                        </p>
                        <img src="Guardian.png" alt="Guardian" class="guardian">
                    </a>
                </div>
                <div class="phantom-bg">
                    <a href="phantom.html">
                        <p class="phantom-name">
                            Phantom Rifle
                        </p>
                        <img src="Phantom.png" alt="Phantom" class="phantom">
                    </a>
                </div>
                <div class="vandal-bg">
                    <a href="vandal.html">
                        <p class="vandal-name">
                            Vandal Rifle
                        </p>
                        <img src="Vandal.png" alt="Vandal" class="vandal">
                    </a>
                </div>
            </div>
        </div>
    </main>