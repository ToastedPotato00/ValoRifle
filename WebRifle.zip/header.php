<header class="header">
        <div class="logo">ValoRifle</div>
        <nav class="main-nav">
            <ul class="nav-list">
                <li><a href="#def">Home</a></li>
                <li><a href="#rifle-list">Rifle List</a></li>
                <li><a href="#footer">Contacts</a></li>
            </ul>
        </nav>
            <a href="https://playvalorant.com/en-us/" class="valo">Valorant</a>
    </header>